package com.thenewboston.kevin;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;

public class Tabs extends Activity implements OnClickListener {
	
	TabHost th;
	TextView showResults; // for StopWatch
	long start = 0, stop; // for StopWatch
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tabs);
		th = (TabHost) findViewById(R.id.tabhost);
		th.setup(); // set the basics of tabhost
		
		Button newTab = (Button) findViewById(R.id.bAddTab);
		Button bStart = (Button) findViewById(R.id.bStartWatch);
		Button bStop = (Button) findViewById(R.id.bStopWatch);
		showResults = (TextView) findViewById(R.id.tvShowResults);
		
		bStart.setOnClickListener(this);
		bStop.setOnClickListener(this);
		newTab.setOnClickListener(this);
		
		TabSpec specs = th.newTabSpec("tag1"); // tag1 doesn't have a purpose for now
		specs.setContent(R.id.tab1); // which holds our two buttons and textview (first linear layout)
		specs.setIndicator("StopWatch");
		th.addTab(specs);
		
		specs = th.newTabSpec("tag2"); // tag2 doesn't have a purpose for now
		specs.setContent(R.id.tab2); // holds the second linear layout
		specs.setIndicator("Tab 2");
		th.addTab(specs);
		
		specs = th.newTabSpec("tag3"); // tag3 doesn't have a purpose for now
		specs.setContent(R.id.tab3); // which holds our two buttons and textview
		specs.setIndicator("Add a Tab");
		th.addTab(specs);
		
		th.getTabWidget().getChildAt(1).setBackgroundColor(Color.RED); // sets a tab to the color red
		
		
	}

	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId())
		{
		case R.id.bAddTab:
			TabSpec ourSpec = th.newTabSpec("tag 1"); // tag 1 is useless
			ourSpec.setContent(new TabHost.TabContentFactory() {
				
				public View createTabContent(String tag) {
					// TODO Auto-generated method stub
					
					TextView text = new TextView(Tabs.this);
					text.setText("You've created a new tab");
					return (text);
				}
			});
			
			ourSpec.setIndicator("New");
			th.addTab(ourSpec);
			
			break;
		case R.id.bStartWatch:
			start = System.currentTimeMillis();
			break;
		case R.id.bStopWatch: 
			stop = System.currentTimeMillis();
			if(start != 0)
			{
				long result = stop - start;
				int millis = (int) result;
				int seconds = (int) result / 1000;
				int minutes = seconds / 60;
				millis = millis % 100;
				seconds = seconds % 60;
				
				showResults.setText(String.format("%d:%02d:%02d", minutes, seconds, millis));
			}
			break;
		}
	}
}
