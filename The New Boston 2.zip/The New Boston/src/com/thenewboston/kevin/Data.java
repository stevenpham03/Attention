package com.thenewboston.kevin;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class Data extends Activity implements OnClickListener {

	EditText sendET;
	Button start, startFor;
	TextView gotAnswer;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.get);
		initializeVars();
	}

	private void initializeVars() {
		// TODO Auto-generated method stub
		sendET = (EditText) findViewById(R.id.etSend);
		start = (Button) findViewById(R.id.bSA);
		startFor = (Button) findViewById(R.id.bSAFR);
		gotAnswer = (TextView) findViewById(R.id.tvGOT);
		start.setOnClickListener(this);
		startFor.setOnClickListener(this);
	}

	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.bSA:
			String bread = sendET.getText().toString();
			Bundle basket = new Bundle();
			basket.putString("key", bread); // key is the label name in the
											// bundle (so we can reference it
											// later)
			Intent a = new Intent(Data.this, OpenedClass.class);
			a.putExtras(basket); // tells the Intent a to carry the basket as
									// you go from Data to OpenedClass
			startActivity(a);
	
			break;
		case R.id.bSAFR: 
			Intent i = new Intent(Data.this, OpenedClass.class);
			String bread2 = sendET.getText().toString();
			Bundle basket2 = new Bundle();
			basket2.putString("key", bread2);
			i.putExtras(basket2);
			
			startActivityForResult(i, 0); // 0 is a default value ... 1) goes to your OpenedClass activity
			break;

		}
	}

	@Override // 3) goes here
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode == RESULT_OK)
		{
			Bundle basket = data.getExtras();
			String s = basket.getString("answer");
			gotAnswer.setText(s);
		}
	}
}
